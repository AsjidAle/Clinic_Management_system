@include('parts/header')

@include('herosection')

@include('mainsection')

@include('parts/footer')