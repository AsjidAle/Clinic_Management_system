
<footer class="text-center">
        <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
            <span class="glyphicon glyphicon-chevron-up"></span>
        </a><br><br>
        <p><span class="text-danger">Hospital</span> Project By <a href="/" data-toggle="tooltip" title="Visit Hospitals">www.hospitals.com</a></p>
    </footer>

</body>
</html>